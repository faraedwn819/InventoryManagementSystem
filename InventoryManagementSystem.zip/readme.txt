How to run the Inventory Management System Project

1. Download the zip file

2. Extract the file

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name stockdb

6. Import stockdb.sql file(given inside the zip package in SQL file folder)

7.Open the ( Spring Tool Suite ) program

8. Open the project ( InventoryManagementSystem ) and run it

Credential for admin (Vendor) :

email: faraedwn.mahmood@gmail.com
Password: faraedwn123